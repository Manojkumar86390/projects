import React, { useState, useEffect } from 'react';
import { ChevronDown, Mail, Phone, MapPin, Github, Linkedin, ExternalLink, GraduationCap, Code, User, X } from 'lucide-react';

const projects = [
  {
    id: 1,
    title: "Project One",
    shortDesc: "Short summary of project one.",
    longDesc:
      "Detailed description of Project One goes here. You can explain goals, technologies, and outcomes. Add project duration and extra pictures below.",
    period: "Jan 2024 – Apr 2024",
    tech: ["React", "Node.js", "MongoDB"],
    image: "https://via.placeholder.com/400x250", // replace with your project image
    gallery: [
      "https://via.placeholder.com/300x200",
      "https://via.placeholder.com/300x200",
    ],
  },
  {
    id: 2,
    title: "Project Two",
    shortDesc: "Short summary of project two.",
    longDesc:
      "Detailed description of Project Two goes here. You can add diagrams, research details, or implementation notes.",
    period: "Aug 2023 – Dec 2023",
    tech: ["MATLAB", "DSP", "Python"],
    image: "https://via.placeholder.com/400x250",
    gallery: [
      "https://via.placeholder.com/300x200",
      "https://via.placeholder.com/300x200",
    ],
  },
];

function ProjectsSection() {
  const [selectedProject, setSelectedProject] = useState<any>(null);

  return (
    <section id="projects" className="py-20 px-6 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Projects</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-teal-600 mx-auto"></div>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer"
              onClick={() => setSelectedProject(project)}
            >
              <img
                src={project.image}
                alt={project.title}
                className="h-48 w-full object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {project.title}
                </h3>
                <p className="text-gray-600 text-sm">{project.shortDesc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Modal for project details */}
        {selectedProject && (
          <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl shadow-xl max-w-3xl w-full p-6 relative">
              {/* Close Button */}
              <button
                className="absolute top-4 right-4 text-gray-600 hover:text-gray-900"
                onClick={() => setSelectedProject(null)}
              >
                <X className="w-6 h-6" />
              </button>

              {/* Project Content */}
              <h3 className="text-2xl font-bold mb-2">
                {selectedProject.title}
              </h3>
              <p className="text-gray-500 text-sm mb-4">
                Duration: {selectedProject.period}
              </p>
              <p className="text-gray-700 mb-4">{selectedProject.longDesc}</p>

              {/* Gallery */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                {selectedProject.gallery.map((img: string, idx: number) => (
                  <img
                    key={idx}
                    src={img}
                    alt={`gallery-${idx}`}
                    className="rounded-lg object-cover"
                  />
                ))}
              </div>

              {/* Tech Stack */}
              <div className="flex flex-wrap gap-2 mb-4">
                {selectedProject.tech.map((tech: string) => (
                  <span
                    key={tech}
                    className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium"
                  >
                    {tech}
                  </span>
                ))}
              </div>

              {/* Buttons */}
              <div className="flex space-x-3">
                <button className="flex items-center text-blue-600 hover:text-blue-800 transition-colors">
                  <Github className="w-4 h-4 mr-1" />
                  Code
                </button>
                <button className="flex items-center text-teal-600 hover:text-teal-800 transition-colors">
                  <ExternalLink className="w-4 h-4 mr-1" />
                  Demo
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function App() {
  const [activeSection, setActiveSection] = useState('hero');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-blue-900">Manoj Kumar</h2>
            <div className="hidden md:flex space-x-8">
              {['About', 'Education', 'Skills', 'Projects', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="text-gray-700 hover:text-blue-600 transition-colors font-medium"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className="min-h-screen flex items-center justify-center px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <div className="w-32 h-32 bg-gradient-to-br from-blue-600 to-teal-600 rounded-full mx-auto mb-6 flex items-center justify-center shadow-lg">
              <User className="w-16 h-16 text-white" />
            </div>
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-4 animate-fade-in">
              Manoj Kumar
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
              Electronic and communication student
            </p>
            <p className="text-lg text-gray-500 max-w-3xl mx-auto mb-12">
              Passionate about technology, programming, and creating innovative solutions. 
              Currently pursuing my education while building exciting projects and expanding my skill set.
            </p>
          </div>
          <button
            onClick={() => scrollToSection('about')}
            className="inline-flex items-center bg-blue-600 text-white px-8 py-4 rounded-full hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Learn More
            <ChevronDown className="ml-2 w-5 h-5" />
          </button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">About Me</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-teal-600 mx-auto"></div>
          </div>
          <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              I'm Manoj Kumar, an Electronics and Communication Engineer passionate about designing 
            and working on innovative electronic systems and communication technologies. My journey 
            began with a curiosity about how circuits and signals work, which led me to develop a 
            strong passion for embedded systems, VLSI design, and digital communications.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              I believe in the power of technology to solve real-world problems and am committed to developing skills that will 
              help me contribute meaningfully to the tech industry.
             
            </p>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 px-6 bg-gradient-to-r from-blue-50 to-teal-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Education</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-teal-600 mx-auto"></div>
          </div>
          <div className="space-y-8">
            {/* College */}
            <div className="bg-white rounded-2xl shadow-lg p-8 transform hover:scale-105 transition-all duration-300">
              <div className="flex items-start space-x-4">
                <div className="bg-blue-100 p-3 rounded-full">
                  <GraduationCap className="w-8 h-8 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Bachelor of Electronic and communication</h3>
                  <p className="text-lg text-blue-600 font-semibold mb-2">Indian Institute Of Information Technology, Design & Manufacturing, Kurnool</p>
                  <p className="text-gray-600 mb-3">2023 - 2027</p>
                  <p className="text-gray-700">
                    Currently pursuing my undergraduate degree in Electronic and communication with focus on core knowledge.
                    
                  </p>
                </div>
              </div>
            </div>

            {/* Intermediate */}
            <div className="bg-white rounded-2xl shadow-lg p-8 transform hover:scale-105 transition-all duration-300">
              <div className="flex items-start space-x-4">
                <div className="bg-teal-100 p-3 rounded-full">
                  <GraduationCap className="w-8 h-8 text-teal-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Intermediate (12th Grade)</h3>
                  <p className="text-lg text-teal-600 font-semibold mb-2">TIRUMALA JUNIOR COLLEGE </p>
                  <p className="text-gray-600 mb-3">2021 - 2023</p>
                  <p className="text-gray-700">
                    Completed higher secondary education with Mathematics, Physics, and Chemistry. 
                    Achieved excellent grades and developed strong analytical and problem-solving skills.
                  </p>
                </div>
              </div>
            </div>

            {/* School */}
            <div className="bg-white rounded-2xl shadow-lg p-8 transform hover:scale-105 transition-all duration-300">
              <div className="flex items-start space-x-4">
                <div className="bg-orange-100 p-3 rounded-full">
                  <GraduationCap className="w-8 h-8 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">High School (10th Grade)</h3>
                  <p className="text-lg text-orange-600 font-semibold mb-2">Sri Chaitanya techno school</p>
                  <p className="text-gray-600 mb-3">2016 - 2021</p>
                  <p className="text-gray-700">
                    Completed secondary education with distinction. Developed foundational knowledge in science and mathematics .
                    
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Skills</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-teal-600 mx-auto"></div>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Programming Languages */}
            <div className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300">
              <div className="bg-blue-100 p-3 rounded-full w-fit mb-6">
                <Code className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-6">Programming Languages</h3>
              <div className="space-y-4">
                {[
                  { name: 'Verilog', level: 85 },
                  { name: 'Python', level: 80 },
                  { name: 'Matlab', level: 75 },
                  { name: 'C++', level: 70 }
                ].map((skill) => (
                  <div key={skill.name} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-700">{skill.name}</span>
                      <span className="text-sm text-gray-500">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-600 to-blue-500 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tools & Others */}
            <div className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300">
              <div className="bg-orange-100 p-3 rounded-full w-fit mb-6">
                <Code className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-6">Tools & Others</h3>
              <div className="space-y-4">
                {[
                  { name: 'Alitum designer', level: 45 },
                  { name: 'Vivado', level: 75 },
                  { name: 'MAtlab', level: 70 },
                  { name: 'VS Code', level: 90 }
                ].map((skill) => (
                  <div key={skill.name} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-700">{skill.name}</span>
                      <span className="text-sm text-gray-500">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-orange-600 to-orange-500 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <ProjectsSection />

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6 bg-gradient-to-br from-gray-900 to-blue-900">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Get In Touch</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-400 to-teal-400 mx-auto mb-6"></div>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              I'm always open to discussing new opportunities, collaborations, or just having a chat about technology.
            </p>
          </div>
          
          {/* Contact Form */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 mb-12 max-w-2xl mx-auto">
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-300"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-300"
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={5}
                  className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-300 resize-none"
                  placeholder="Tell me about your project or just say hello..."
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-teal-600 text-white py-3 px-8 rounded-lg hover:from-blue-700 hover:to-teal-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                Send Message
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all duration-300">
              <Mail className="w-8 h-8 text-blue-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Email</h3>
              <p className="text-gray-300">manojkumardannana@email.com</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all duration-300">
              <MapPin className="w-8 h-8 text-orange-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Location</h3>
              <p className="text-gray-300">vizag, India</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all duration-300">
              <Github className="w-8 h-8 text-teal-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">GitHub</h3>
              <p className="text-gray-300">github.com/manojkumar</p>
            </div>
          </div>

          <div className="flex justify-center space-x-6">
            <a href="https://github.com/manojkumar" target="_blank" rel="noopener noreferrer" className="bg-white/10 backdrop-blur-sm p-4 rounded-full hover:bg-white/20 transition-all duration-300 transform hover:scale-110">
              <Github className="w-6 h-6 text-white" />
            </a>
            <a href="https://www.linkedin.com/in/manoj-kumar-52600a2a8?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" target="_blank" rel="noopener noreferrer" className="bg-white/10 backdrop-blur-sm p-4 rounded-full hover:bg-white/20 transition-all duration-300 transform hover:scale-110">
              <Linkedin className="w-6 h-6 text-white" />
            </a>
            <a href="mailto:manojkumardannana@gmail.com" className="bg-white/10 backdrop-blur-sm p-4 rounded-full hover:bg-white/20 transition-all duration-300 transform hover:scale-110">
              <Mail className="w-6 h-6 text-white" />
            </a>
          </div>
          
          {/* Contact via Phone */}
          <div className="mt-16 pt-8 border-t border-white/20">
            <div className="bg-gradient-to-r from-blue-600/20 to-teal-600/20 backdrop-blur-sm rounded-2xl p-8 max-w-md mx-auto">
              <Phone className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-3">Contact Me Via Phone</h3>
              <p className="text-gray-300 mb-4">
                Prefer to talk directly? Give me a call for immediate assistance or quick discussions.
              </p>
              <a 
                href="tel:+919876543210"
                className="inline-flex items-center bg-white/20 text-white px-6 py-3 rounded-full hover:bg-white/30 transition-all duration-300 font-semibold"
              >
                <Phone className="w-5 h-5 mr-2" />
                +91 8639059067
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-center py-8">
        <p className="text-gray-400">
          Thank You From  Manoj Kumar.
        </p>
      </footer>
    </div>
  );
}

export default App;